import detect
t = detect.parse_opt()
detect.main(t)
